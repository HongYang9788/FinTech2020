R08631011 生機所碩二 林宏陽

1. File name: ProjectA.ipynb
2. First cell: function definition
3. Second cell: main progress
4. Execute the second cell, and input the node respectively.